/* ======================================================================= *//**
 * @Component			OMAPCONF
 * @Filename			version.h
 * @Description			version
 * @Copyright			GPL version 2
 *//*======================================================================== */
/*
    version.h
    Copyright (C) 2006 Jean Delvare <khali@linux-fr.org>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
*/


#define VERSION "3.1.0"
